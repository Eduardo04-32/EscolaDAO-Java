create database escoladao;
use escoladao;

create table alunos 
(
id int primary key auto_increment, nome varchar(50)
)